# Arbeitspaket Altersbestätigung 18+

Die vorhandene Casino-Login-Seite wurde um eine Altersbestätigung mit JavaScript ergänzt.

- Beim ersten Besuch erscheint die Frage, ob die Person mindestens 18 Jahre alt ist.
- Ja gibt die Login-Seite frei und setzt den Fokus in das Benutzername-Feld.
- Nein zeigt eine Sperrmeldung; die Casino-Seite bleibt verborgen und nicht bedienbar.
- Beide Entscheidungen werden mit sessionStorage im aktuellen Browser-Tab gespeichert und beim Neuladen berücksichtigt.
- Ist der Sitzungsspeicher nicht verfügbar, funktioniert die Auswahl trotzdem. Nach dem Neuladen wird erneut gefragt.
- Ohne JavaScript bleibt die Seite gesperrt und zeigt einen Hinweis.

## Dateien

- index.html: Frage, Buttons und gesperrter Casino-Bereich
- style.css: Gestaltung und Ausblenden gesperrter Bereiche
- age-check.js: Ereignisse, Freigabe, Sperre und Sitzungsspeicher

## Lokal öffnen

Alle Dateien samt assets im gleichen Ordner belassen und index.html im Browser öffnen.
Die Anmeldung selbst ist weiterhin ein separates Arbeitspaket.

Die Abfrage ist eine Selbstauskunft. Die Altersentscheidung wird nicht an ein Backend geschickt.
