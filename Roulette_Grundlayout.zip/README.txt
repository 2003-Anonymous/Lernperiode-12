Roulette Grundlayout

roulette.html und roulette.css im selben Ordner belassen.
Zum Ansehen roulette.html im Browser öffnen.

Enthalten: statisches Roulette-Rad, Setzfeld 0 bis 36, Wettbereiche,
Beispielguthaben, Einsatzfeld, Jetons und Aktionsbuttons.

Dies ist ausschliesslich das HTML/CSS-Grundlayout.
Die Spiel- und Auszahlungslogik sowie die Backend-Anbindung folgen später.
Spiel-Buttons sind in dieser Vorschau bewusst deaktiviert.

Orientierung für das europäische Setzfeld:
Casinos Austria – Roulette Spielanleitung
https://www.casinos.at/fileadmin/00_Casinos/12_Downloads/02_Folder/spielerklaerung-roulette.pdf
